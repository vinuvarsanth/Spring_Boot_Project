package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Product;
import com.example.demo.Model.RegistrationEntity;
import com.example.demo.Repository.ProductRepo;
import com.example.demo.Repository.RegistrationRepo;
import com.example.demo.dto.OrderRequest;

@RestController
public class OrderController {

    @Autowired
    private ProductRepo productRepo;

    @SuppressWarnings("null")
    @PostMapping("/placeOrder")
    public Product placeOrder(@RequestBody OrderRequest request) {
        return productRepo.save(request.getProduct());
    }

    @GetMapping("/findAllOrders")
    public Page<Product> findAllOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "pid") String sortBy) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));

        return productRepo.findAll(pageable);
    }

    @Autowired
    RegistrationRepo repo;

    @GetMapping("/details")
    public List<RegistrationEntity> getDetails() {
        List<RegistrationEntity> registrationEntities = repo.findAll();
        return registrationEntities;
    }

    @GetMapping("/details/{id}")
    public RegistrationEntity getRegistrationEntity(@PathVariable int id) {
        RegistrationEntity registrationEntity = repo.findById(id).get();
        return registrationEntity;
    }

    @SuppressWarnings("null")
    @PostMapping("/details/add")
    @ResponseStatus(code = HttpStatus.CREATED)
    public void createRegistrationEntity(@RequestBody RegistrationEntity registrationEntity) {
        repo.save(registrationEntity);
    }

    @PutMapping("/details/update/{id}")
    public ResponseEntity<RegistrationEntity> updateRegistrationEntity(@PathVariable int id,
            @RequestBody RegistrationEntity updatedEntity) {
        RegistrationEntity registrationEntity = repo.findById(id).orElse(null);
        if (registrationEntity != null) {
            if (updatedEntity.getName() != null && !updatedEntity.getName().isEmpty()) {
                registrationEntity.setName(updatedEntity.getName());
            }
            if (updatedEntity.getEmail() != null && !updatedEntity.getEmail().isEmpty()) {
                registrationEntity.setEmail(updatedEntity.getEmail());
            }
            if (updatedEntity.getGender() != null && !updatedEntity.getGender().isEmpty()) {
                registrationEntity.setGender(updatedEntity.getGender());
            }
            if (updatedEntity.getPhoneNumber() != 0) {
                registrationEntity.setPhoneNumber(updatedEntity.getPhoneNumber());
            }
            if (updatedEntity.getPassword() != null && !updatedEntity.getPassword().isEmpty()) {
                registrationEntity.setPassword(updatedEntity.getPassword());
            }
            registrationEntity = repo.save(registrationEntity);
            return ResponseEntity.ok(registrationEntity);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @SuppressWarnings("null")
    @DeleteMapping("/details/delete/{id}")
    public void removeRegistrationEntity(@PathVariable int id) {
        RegistrationEntity registrationEntity = repo.findById(id).get();
        repo.delete(registrationEntity);
    }
}
